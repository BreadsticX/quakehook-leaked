proggy.zip -> /Library/Fonts/
sdl2.zip -> /Library/Frameworks/
skin_data.json -> n/a

